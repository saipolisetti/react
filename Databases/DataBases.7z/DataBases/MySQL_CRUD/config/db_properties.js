/*
    this file used to maintain the database properties
*/
module.exports = {
    host    :       "localhost",
    user    :       "root",
    password:       "root",
    database:       "mean"
};