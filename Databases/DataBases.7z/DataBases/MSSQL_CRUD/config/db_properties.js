module.exports = {
    server  :   "localhost",
    user    :   "sa",
    password:   "123",
    database:   "mean"
};