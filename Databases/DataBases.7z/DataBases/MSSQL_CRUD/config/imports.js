module.exports = {
    express :   require("express"),
    mssql   :   require("mssql"),
    bodyparser: require("body-parser"),
    cors:require("cors")
};