module.exports = {
    express     :       require("express"),
    mongodb     :       require("mongodb"),
    cors        :       require("cors"),
    bodyparser  :       require("body-parser")
};  